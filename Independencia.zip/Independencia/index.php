<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    <center>
        <h1>A Independência do Brasil: 200 anos</h1></center>
    <style>
         body
  {background-color: rgb(255,250,240)
       }
  
  h1{
      background-color: goldenrod; font-family: sans-serif;
      
      }
      
      h2 {
          font-family: sans-serif;
      }
      
      h3{
          font-family: sans-serif;
      }
      ul {
        font-family: sans-serif;  
      }
  p
  {
      font-family: sans-serif; text-justify:auto;  
  }
 
  div {
      text-align: center;
  }
    </style>

    </head>
    <body>
        <?php
        ?>
      
        <h2>&rarr;Antecedentes</h2><br>
        <ul>
            <li>7 anos antes, o Brasil já não era mais uma colônica, mas um Reino Unido a Portugal;</li><br>
            <li>Dom João VI retorna a Portugal e deixa seu filho D. Pedro como príncipe regente;</li><br>
            <li>D. Pedro precisou declarar que permaneceria no Brasil após pressão de Portugal para seu retorno;</li><br>
            <li>O famoso "grito de independência" ocorreu em 7 de Setembro de 1822, e é comemorado até hoje.</li><br>
             <image src="https://s2.static.brasilescola.uol.com.br/be/2021/05/independencia-brasil.jpg">
        </ul>
        <p>A proclamação da Independência brasileira, em 7 de setembro de 1822, foi um passo decisivo para o início da organização do estado brasileiro. Isso porque significou soberania para que o país pudesse estabelecer suas normas políticas e sua administração pública.</p> 
            <p>Tanto é que dois anos depois, o Brasil já tinha sua primeira constituição. </p>
            <p>Inclusive, até hoje há controvérsias entre os estudiosos a respeito da data da Independência e mesmo do papel ativo de D. Pedro I para que ela se efetivasse. A verdade é que houve uma pressão muito grande para que isso acontecesse. Isso porque os proprietários</p><!-- comment --> 
            <p>rurais e de escravos temiam perder a liberdade econômica que ganharam com a vinda da famímia Imperial para o Brasil e abertura dos portos.</p>
        <p>Quando D. João VI voltou para Portugal em 1820 e deixou seu filho D. Pedro, o clima político indicava que o Brasil sofreria uma amneaça a liberdade novamente.</p>
        <p>Esse movimento de liberdade econômica no Brasil não resultou em transformações políticas profundas, e nem sociais, porque D. Pedro já governava o país desde que D. João VI havia voltado para Portugal.</p><!-- comment --> 
        <p>Pode-se concluir que na verdade foi uma independência sem muitas mudanças no quadro político e social do país.</p>
        <h3>&Rarr;Curiosidade:</h3>
        <div><image src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/29-_Imperatriz_rainha_D._Leopoldina.jpg/255px-29-_Imperatriz_rainha_D._Leopoldina.jpg"></div>
        <p>D. Pedro entregou o poder a D. Leopoldina, no dia 13 de agosto de 1822, nomeando-a chefe do Conselho de Estado e Princesa Regente Interina do Brasil. D. Pedro partiu para tentar acabar com um conflito em São Paulo. Por conta das notícias vindas de Portugal,
        <p>Dona Leopoldina não teve tempo de esperar pelo marido e precisou tomar uma decisão, na qual foi aconselhada por José Bonifácio de Andrada e Silva. 
        <p>Após a assinatura do decreto, ela enviou uma carta a D. Pedro para que ele proclamasse a Independência do Brasil. O papel chegou a ele no dia 7 de setembro de 1822, quando D. Pedro proclamou o Brasil livre de Portugal, às margens do Rio Ipiranga, em
        <p>São Paulo</p>
    </body>
</html>
